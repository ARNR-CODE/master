package se.WeatherForCast.awspring;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import se.WeatherForCast.awspring.configuration.Weather;

@SpringBootApplication
public class AwspringApplication {



    public static void main(String[] args) {
//        SpringApplication app = new SpringApplication (AwspringApplication.class);
//        app.run ();
        Logger log = LoggerFactory.getLogger(AwspringApplication.class);
        ConfigurableApplicationContext ctx = SpringApplication.run(AwspringApplication.class);
        LocationKey key = ctx.getBean(LocationKey.class);
        log.info(key.getKey());

    }






//    @Override
//    public void run(String... args) throws Exception {
//        Logger log = LoggerFactory.getLogger(AwspringApplication.class);
//        log.info(weather.toString());
//    }
}
