package se.WeatherForCast.awspring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import se.WeatherForCast.awspring.configuration.Weather;


@Component
public  class LocationKey {
//
    @Autowired
    private RestTemplate restTemplate;


    private String key;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

        public LocationKey (Weather weather) {
            key = getToken(weather);
        }


        private  String  getToken(Weather weather) {
           restTemplate = new RestTemplate();
           String url = buildingURL (weather);
           return restTemplate.getForObject(url, String.class);
        }

        private  String buildingURL(Weather weather) {
            StringBuilder url = new StringBuilder();
            url.append(weather.getBaseUrl());
            url.append(weather.getDailyUrl());
            url.append("?apikey=" + weather.getApikey());
            return url.toString();
        }

}