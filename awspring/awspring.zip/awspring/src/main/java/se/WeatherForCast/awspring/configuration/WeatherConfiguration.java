package se.WeatherForCast.awspring.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;
import se.WeatherForCast.awspring.LocationKey;

@Configuration
@ComponentScan(basePackageClasses = LocationKey.class )
public class WeatherConfiguration {

    @Autowired
    private Weather weather;

    @Bean
    public LocationKey getLocationKey() {
        return new LocationKey(weather);
    }

    @Bean
    public RestTemplate getRestTemplate() {
        return new RestTemplate();
    }


}
