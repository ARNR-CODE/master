package se.WeatherForCast.awspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AwspringApplicationTests {

	@Test
	void contextLoads() {
	}

}
